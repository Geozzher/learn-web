const RequestParser = require('./RequestParser');
const makeResponse = require('./makeResponse');
const path = require('path');

const POSTPlugin = require('./POSTPlugin');
const GETPlugin = require('./GETPlugin');
const PUTPlugin = require('./PUTPlugin');
const DELETEPlugin = require('./DELETEPlugin');

module.exports = (connection) => {

  const parser = new RequestParser();
  const env = {
    root: path.resolve('./www')
  }

  connection.on('data', (buffer) => {
    parser.append(buffer);
  });

  parser.on('finish', (message) => {
    // plugin 0
    message = POSTPlugin(message, env);
    message = GETPlugin(message, env);
    message = PUTPlugin(message, env);
    message = DELETEPlugin(message, env);
    // make reqsonse
    connection.end(makeResponse(message));
  })
}
